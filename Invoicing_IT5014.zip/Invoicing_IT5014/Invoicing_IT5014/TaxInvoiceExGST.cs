﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoicing_IT5014

//the TaxInvoiceExGST class is derived from the TaxInvoice class and the abstract class Splittable

{
    class TaxInvoiceExGST : TaxInvoice, Splittable
    {
        //The method below is the constructor for the TaxInvoiceEXGST and its base TaxInvoice class
        public TaxInvoiceExGST(int custNo, string product, float unitPrice, int quantity)
            : base(custNo, product, unitPrice, quantity)
        {
        }


        //this method sets the GST value to 0
        public override void CalculateGST()
        {
            GST = 0;
        }


        //this method changes the Print method to print the Ex-GST method and prints the output
        public override string Print()
        {
            string output;
            output = "EX-GST ";
            output += base.Print();
            return output;
        }


        //this method adds the paid amount to already paid amount

        internal float paid = 0;
        public void MakePayment(float amount)
        {
            paid += amount;
        }


        //this method calculates the amount still owing
        public float StillOwing()
        {
            return unitPrice * quantity - paid;
        }
    }
}
