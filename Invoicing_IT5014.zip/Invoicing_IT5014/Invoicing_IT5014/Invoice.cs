﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoicing_IT5014
{

    //We have declared Invoice as the abstract class because it is the base class of InternalInvoice, TaxInvoice, TaxInvoiceExGST, but it is not instantiated on its own.
    public abstract class Invoice
    {
        //this is a static variable called lastInvoiceNo,which is incremented to get the invoice no
        internal static int lastInvoiceNo = 1000;
        
        internal int invoiceNo;
        internal int custNo;
        internal string product;
        internal float unitPrice;
        internal int quantity = 1;

        //RevenueValue() is an abstract method used in derived classes of the Invoice class which are InternalInvoice,TaxInvoice and the Main class 
        public abstract float RevenueValue();



        public Invoice()
        {
            invoiceNo = 10002;
            custNo = 18;
            product = "Monitor d900";
            unitPrice = 655;
            quantity = 1;
        }

        public Invoice(int custNo, string product, float unitPrice, int quantity):
            this (custNo, product, unitPrice)
        {
            //this.invoiceNo = invoiceNo;
            //this.custNo = custNo;
            //this.product = product;
            //this.unitPrice = unitPrice;
            this.quantity = quantity; //this keyword is used to refer to the current instance of the class
        }

        public Invoice(int custNo, string product, float unitPrice)
        {
            //this.invoiceNo = invoiceNo;
            invoiceNo = ++lastInvoiceNo;
            this.custNo = custNo;
            this.product = product;
            this.unitPrice = unitPrice;
            //this.quantity = 1;
        }

        //The Print method is declared as virtual because it can be modified by its derived classes
        //It is referred in the Main class, the TaxInvoice class and the TaxInvoiceExGST class
        public virtual string Print()
        {
            string output = "";
            output += "Invoice:  " + invoiceNo;
            output += "\r\n";
            output += "Customer:  " + custNo;
            output += "\r\n";
            output += "Product:  " + product;
            output += "\r\n";
            output += "Unit Price:  " + unitPrice;
            output += "\r\n";
            output += "Quantity:  " + quantity;
            output += "\r\n";
            return output;
         }

        public void Email(string address)
        {
            Console.WriteLine("Emailing Invoice " + invoiceNo + " to " + address);
        }

        public void Store()
        {
            Console.WriteLine("Storing invoice " + invoiceNo);
        }    
    }
}
