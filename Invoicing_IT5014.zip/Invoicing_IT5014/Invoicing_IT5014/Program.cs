﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*The Invoicing_5014 project is designed to keep track of the stationery company’s invoices. 
 * It will allow the user to browse the invoice information for all the invoices created, calculate company’s revenue, 
 * make payments to cover outstanding invoices and display the balance still owed.
 * 
 * When the program is run, the option menu should be displayed. Based you the selection provided, 
 * it will allow you to perform one of the operations listed above, then present the options menu again. 
 * You may continue performing invoicing operations until you press ‘X’, which will close the program.
 */


namespace Invoicing_IT5014
{


    class Program
    {   /*The following code creates instances of the Invoice class for the Printer and Monitor
         * the TaxInvoiceExGST class for the Milk and Bread and
         * the InternalInvoice class for the IT Support
         */
        static Invoice PrinterInvoice = new TaxInvoice(26, "Printer i40", 230, 3);
        static Invoice MonitorInvoice = new TaxInvoice(18, "Monitor UP3214", 655, 1);
        static TaxInvoiceExGST MilkInvoice = new TaxInvoiceExGST(46, "Milk - 2 litres", 2.85f, 5);
        static TaxInvoiceExGST BreadInvoice = new TaxInvoiceExGST(46, "Bread - white", 3.15f, 2);
        static InternalInvoice ITSupportInvoice = new InternalInvoice(101, "DVD Drive", 58.1f, 1);

        static void Main(string[] args)
        {
            String stringAmount;
            float amount = 0; ;
            bool amountCorrect = false;
            while (true)
            {
                //The DisplayMenu() method displays the menu for the different options
                DisplayMenu();
                //The input variable accepts the input from the user and converts it to lower case
                String input = Console.ReadLine().ToLower();
                 
                //the input is validated by the InputValid method

                if (InputValid(input))
                {
                    /*If the input is "s", all the invoices are shown
                     * if it is "r", the total revenue is calculated
                     * if it is "m", the total amounttopay is accepted from the user
                     *it is converted to amount using the TryParse method
                     *The amount is then paid to the Milk Invoice using the InvoicePayment method
                     *if it is "it", then the amount is paid to the ITSupport Invoice using the Invoice Payment method in
                     *if it is "x" the the program exits
                     */
                    switch (input)
                    {
                        case "s":
                            ShowAllInvoices();                        
                            break;
                        case "r":
                            Console.WriteLine("Total Revenue: $" + CalculateRevenue());
                        
                            break;
                        case "m":
                            Console.WriteLine("Enter the amount to pay");
                            stringAmount = Console.ReadLine();
                            amountCorrect = float.TryParse(stringAmount, out amount);
                            if (amountCorrect)
                            {
                                InvoicePayment(MilkInvoice, amount);
                            }                    
                            break;
                        case "it":
                            Console.WriteLine("Enter the ammount to pay");
                            stringAmount = Console.ReadLine();
                            amountCorrect = float.TryParse(stringAmount, out amount);
                            if (amountCorrect)
                            {
                                InvoicePayment(ITSupportInvoice, amount);
                            }
                         
                            break;
                        case "x":
                            Console.WriteLine("exiting the program...");
                            Environment.Exit(0);
                            break;
                    }                    
                }
            
            }
        }

        // this method displays the menu
        private static void DisplayMenu()
        {
            Console.WriteLine("Select an option from the menu below");
            Console.WriteLine("S - Show Invoices");
            Console.WriteLine("R - Calculate Revenue");
            Console.WriteLine("M - Pay Milk Invoice");
            Console.WriteLine("IT - Pay IT Invoice");
            Console.WriteLine("X - Exit");
        }

        //this method validates the input received from the user
        private static bool InputValid(string input)
        {
            if (input == "s" || input == "r" || input == "m" || input == "it" || input == "x")
            {
                return true;
            }
            else
                return false;
        }

        //this is a method from the Invoice class that prints the Invoice No, Cust No, Product No, Unit Price and Quantity
        public static void ShowInvoice(Invoice PrintInv)
        {
            Console.Write(PrintInv.Print());
        }

        //this method passes the value to the abstract method RevenueValue in the Invoice class
        public static float ShowRevenue(Invoice ShowInv)
        {
            return ShowInv.RevenueValue();
        }


        //this method shows all the different types of invoices
       
        private static void ShowAllInvoices()
        {
            ShowInvoice(PrinterInvoice);
            ShowInvoice(MonitorInvoice);
            ShowInvoice(MilkInvoice);
            ShowInvoice(BreadInvoice);
            ShowInvoice(ITSupportInvoice);
        }

        //this method calculates the total Revenue value
        private static float CalculateRevenue()
        {
            float Total = 0;
            Total += ShowRevenue(PrinterInvoice);
            Total += ShowRevenue(MonitorInvoice);
            Total += ShowRevenue(MilkInvoice);
            Total += ShowRevenue(BreadInvoice);
            Total += ShowRevenue(ITSupportInvoice);
            return Total;
        }

        //this method calculates the amount owing by calling the StillOwing() method from the abstract class Splittable

        private static void InvoicePayment(Splittable InvoiceToPay, float amount)
        {

            InvoiceToPay.MakePayment(amount);
            Console.WriteLine("Thank you. $" + InvoiceToPay.StillOwing() + " remains.");
        }
    }
}

