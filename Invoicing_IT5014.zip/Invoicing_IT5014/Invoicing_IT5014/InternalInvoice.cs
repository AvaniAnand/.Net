﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoicing_IT5014
{
    //InternalInvoice is derived from the Invoice class and the abstract class Splittable
    class InternalInvoice : Invoice, Splittable
    {   

        //below is the constructor for the InternalInvoice class and its base class
        public InternalInvoice(int custNo, string product, float unitPrice, int quantity): base(custNo, product, unitPrice, quantity) { }

        //below the abstract method RevenueValue() is modified using the override keyword
        public override float RevenueValue()
        {
            return 0;
        }

        internal float paid = 0;
        //the abstract methods MakePayment and StillOwing from the Splittable class are defined below:
        public void MakePayment(float Amount)
        {
            //The amount paid is assigned to the paid variable
            paid += Amount;
        }

        public float StillOwing()
        {    

            //Actual amount owed is computed by calculating the actual price and subtracting the amount paid from it
            return unitPrice * quantity - paid;
        }
    }
}
