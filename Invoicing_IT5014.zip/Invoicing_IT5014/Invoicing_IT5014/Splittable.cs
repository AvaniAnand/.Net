﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoicing_IT5014
{

    //We have used the Splittable interface below to achieve multiple inheritance.
    //Splittable interface is like an abstract class that has abstract methods, MakePayment() and StillOwing() . These methods do not have a body and cannot be instantiated.
    interface Splittable
    {
        void MakePayment(float amount);
        float StillOwing();
    }
}
