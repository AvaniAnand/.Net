﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoicing_IT5014
{

    //the TaxInvoice class is derived from the Invoice class 

    class TaxInvoice: Invoice
    {
        internal float GST = 0.0f;

        //The method below calculates the GST
        public virtual void CalculateGST()
        {
            GST = unitPrice * quantity * 0.125f;
            
        }

        //The method below is the constructor for the TaxInvoice and its base class

        public TaxInvoice(int custNo, string product, float unitPrice, int quantity)
            : base(custNo, product, unitPrice, quantity)
        {

        }

        //the method below prints the tax invoice and the GST and the Total amount

        public override string Print()
        {
            string output;

            output = "Tax Invoice\r\n";
            output += base.Print();
            CalculateGST();

            output += "\r\n";
            output += "GST:  $" + Math.Round(GST, 2) + "\r\n";
            output += "Total:  $" + Math.Round((unitPrice * quantity + GST), 2) + "\r\n\r\n";

            return output;
        }


        // the method below calculates the value of the Revenue
        public override float RevenueValue()
        {
           return unitPrice * quantity;
        }
    }
}
