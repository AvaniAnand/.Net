﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace IT5014_TicketingProject
{


    //class describing the statistics of the tickets resolved
    //The Ticket Resolution system, Statistics class is a list of tickets.


    public class TicketStatistics
    {

        
        
        //Create the list that holds the tickets
        public List<Ticket> tktList = new List<Ticket>();
        public int totalCreated = 0;
        public int totalResolved = 0;
        public int totalToSolve = 0;

        //count the no of tickets open,closed and total
        public int CountTickets(string value)
        {
            int cnt = 0;

            switch (value)
            {

                case "open":
                    {
                        foreach (Ticket t in tktList)

                        {
                            if ((t.getTicketStatus() == "Open") || (t.getTicketStatus() == "Reopened"))
                            {

                                cnt++;

                            }
                        }
                        break;
                    }
                case "closed":
                    {
                        foreach (Ticket t in tktList)

                        {
                            if (t.getTicketStatus() == "Closed")
                            {

                                cnt++;

                            }
                        }
                        break;
                    }

                case "total": //if total is chosen
                    {
                        cnt = tktList.Count;
                    }

                    break;
            }

            return cnt;
        }

        public void addTicket(Ticket t)
        {

            //the Ticket object passed in is added to the TicketList

            tktList.Add(t);

        }
        public void showStatistics()
        {
            //this loop goes over each ticket in the TicketList
            //Displays the total Tickets, the no of tickets resolved and the no of tickets to solve

            totalCreated = CountTickets("total");
            totalResolved = CountTickets("closed");
            totalToSolve = CountTickets("open");

            Console.WriteLine("Displaying Ticket Statistics:\n\n");
            Console.WriteLine("Tickets Created:" + totalCreated);
            Console.WriteLine("Tickets Resolved:" + totalResolved);
            Console.WriteLine("Tickets To Solve:" + totalToSolve);



        }

       public void TktResponse()
        {
            foreach (Ticket t in tktList)
            {
                if (t._strResponse.Contains("Password Change"))
                {
                    PasswordGenerator objPasswordGenerator = new PasswordGenerator(t._strStaffID, t._nTicketNumber);

                    string Pwd = objPasswordGenerator.genPwd();
                    t._strResponse = "New password generated:" + Pwd;


                }

                else if (t._strIssueDescription.Contains("My monitor stopped working"))
                {


                    Ticket tkt = new Ticket();

                    tkt._strResponse = "The monitor has been replaced.";

                };




            }
        }
    }
}









