﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IT5014_TicketingProject
{
    //An OOP program dealing with tickets, their resolution and the statistics of Resolution
    //We have written the Ticket class, the TicketStatistics class and the PasswordGenerator class
    //We will create a few tickets and add them to the TicketList

    class Program
    {

        
        static void Main(string[] args)
        {
        

        Console.WriteLine("Welcome to the Issue Resolution Ticketing System\n\n");
            
            
           

            //Creating the three ticket objects of the ticket class 

            Ticket Ticket1 = new Ticket("INNAM", "Inna", "inna@whitecliffe.co.nz", "My monitor stopped working");
            Ticket Ticket2 = new Ticket("MARIAH", "Maria", "maria@whitecliffe.co.nz", "Request for a videocamera to conduct webinars");
            Ticket Ticket3 = new Ticket("JOHNS", "John", "john@whitecliffe.co.nz", "Password change");
            


            //Create TicketStatistics object to display the statistics...
            TicketStatistics TktStats = new TicketStatistics();

            //add the tickets to the TicketStatistics object
            TktStats.addTicket(Ticket1); //addTicket is a method from TktStats(Ticket Statistics class) that allows a ticket to be added)
            TktStats.addTicket(Ticket2);
            TktStats.addTicket(Ticket3);

            
            //In the first instance, the third ticket is responded to,
            //so we call the instance of the third ticket,
            //print its statistics and then print the tickets 
            
            Ticket3.TktResponse();
            TktStats.showStatistics();
            Console.WriteLine("\n");
            Console.WriteLine("Printing Tickets:\n\n");
            Ticket1.TktPrint();
            Ticket2.TktPrint();
            Ticket3.TktPrint();

            //In the second instance, the first ticket is responded to,
            //so we call the instance of the first ticket,
            //print its statistics and then print the tickets 


            Ticket1.TktResponse();
            TktStats.showStatistics();
            Console.WriteLine("\n");
            Console.WriteLine("Printing Tickets:\n\n");
            Ticket1.TktPrint();
            Ticket2.TktPrint();
            Ticket3.TktPrint();

            //In the third instance, the third ticket is called again or reopened,
            //so we call the instance of the third ticket, increment the counter by 1 to keep a track of the iterations,
            //we respond adequately to the third ticket and then show the statistics and print the ticket
            
            Ticket3._nCount++;
            Ticket3.TktResponse();
            TktStats.showStatistics();
            Console.WriteLine("\n");
            Console.WriteLine("Printing Tickets:\n\n");
            Ticket1.TktPrint();
            Ticket2.TktPrint();
            Ticket3.TktPrint();
            
        }

    }
}
