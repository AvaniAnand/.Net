﻿using System;

namespace CarSolution
{
    class Program
    {
        static void Main(string[] args)
        {
            Car objCar = new Car();

            string strMyColor = "Black";
            objCar.setColor(strMyColor);

            string strColorCar1 = objCar.getColor();
            string strModelCar1 = objCar.getModel();
            string strTypeCar1 = objCar.getType();

            Console.WriteLine("Car Color is " + strColorCar1);
            Console.WriteLine("Car Model is " + strModelCar1);
            Console.WriteLine("Car Type is " + strTypeCar1);

            //My choice is
            string strColor = "Blue";
            string strModel = "Sports";
            string strType = "Auto";
            Car objCarCustm = new Car(strColor, strType, strModel);
            int nStop = 0;
        }
    }
}
