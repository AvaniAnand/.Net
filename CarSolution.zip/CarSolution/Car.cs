﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarSolution
{
    class Car
    {
        //Attributes
        int _nReg;
        string _strColor;
        string _strType;
        string _strModel;

        //Constructor
        public Car()
        {
            _nReg = 0;
            _strColor = "Red";
            _strType = "Auto";
            _strModel = "Jazz";
        }

        public Car(string strColor, string strType, string strModel)
        {
            _nReg = 0;
            _strColor = strColor;
            _strType = strType;
            _strModel = strModel;

        }

        //Methods
        //public return_type method_name()
        public string getColor()
        {
            return _strColor;
        }

        public string getModel()
        {
            return _strModel;
        }

        public string getType()
        {
            return _strType;
        }

        //To set variable
        //publlic void method_name(variable to set)
        public void setColor(string strColor)
        {
            _strColor = strColor;
        }

        public void setModel(string strModel)
        {
            _strModel = strModel;
        }

        public void setType(string strType)
        {
            _strType = strType;
        }

    }
}
